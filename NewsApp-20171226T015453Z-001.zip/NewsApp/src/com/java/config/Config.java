package com.java.config;

public class Config {

	public static String IP="http://192.168.42.1";
	public static String UserID;
	public static String UserType;
	public static String UserFavourite;
}
