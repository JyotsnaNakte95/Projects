package com.java.models;

public class Admin_PanelModel {

	private String NewsID;
	private String Title;
	private String New_Source;
	private String Short_Details;
	private String Image_Location;
	public String getNew_Type() {
		return New_Type;
	}
	public void setNew_Type(String new_Type) {
		New_Type = new_Type;
	}
	private String New_Type;
	public String getNewsID() {
		return NewsID;
	}
	public void setNewsID(String newsID) {
		NewsID = newsID;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getNew_Source() {
		return New_Source;
	}
	public void setNew_Source(String new_Source) {
		New_Source = new_Source;
	}
	public String getShort_Details() {
		return Short_Details;
	}
	public void setShort_Details(String short_Details) {
		Short_Details = short_Details;
	}
	public String getImage_Location() {
		return Image_Location;
	}
	public void setImage_Location(String image_Location) {
		Image_Location = image_Location;
	}
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	private String UserID;
}
