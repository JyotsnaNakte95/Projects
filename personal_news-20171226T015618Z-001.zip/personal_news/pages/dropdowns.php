<?php

$news_category=array("Sports","Technology","Business","Entertainment","Science","Health");

$news_menu=array("All","Sports","Technology","Business","Entertainment","Science","Health");

?>