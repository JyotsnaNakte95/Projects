<?php
if(!isset($_SESSION)) 
{ 
					ob_start();
					session_start();
							//echo "Session started";
					//	print_r($_SESSION);
} 
?>