<html>
 
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href='css/w3.css' />
<link rel="stylesheet" href='css/user_index.css' />
<title>Welcome to Personalized News </title>

<style>
	 
	.signin  	{
		position:relative;
		top:100px;
		padding:12px 5px 5px 5px;
		width:200px;
		height:50px;
		
	}
	
	.signup  	{
		position:relative;
		top:150px;
		padding:12px 5px 5px 5px;
		width:200px;
		height:50px;
		
	}
</style>
</head>


<body>
 
 <br>
 <center><h1 style="color:white;font-weight:bolder">Welcome to Personalized News</h1></center>
 <br>
 <div align="center">
			<a href="pages/login.php" class="w3-btn signin w3-khaki"><span>Sign In</span> </a>
			<br>
			<a href="pages/register.php" class="w3-btn signup w3-red">Sign Up</a>
		
 </div>
 
</body>

<script>
</script>

</body>
</html>